# DP01 Prophet Signals — Subscription Service

AI-native sports signals subscription (Build with Gemini XPRIZE entry).
33-day plan, $1.99. Gemini-powered chat + reporting. No fund custody, no trade
execution on the user's behalf — signals/insights only.

## Architecture

- **Cloud Run** — `app/main.py`: FastAPI service exposing `/chat`, `/report`, `/webhook/stripe`
- **Firestore** — subscribers, signal history, agent execution logs
- **Cloud Scheduler** — triggers `app/scheduler/run_daily_signals.py` daily
- **Gemini API** — `app/agents/chat_agent.py`, `app/agents/report_agent.py`
- **Stripe** — subscription billing, webhook-driven access provisioning
- **Google Workspace MCP** — Sheets/Drive logging under least-privilege OAuth scopes

## Setup

1. `cp .env.example .env` and fill in values (GCP project, Gemini API key, Stripe keys).
2. `pip install -r requirements.txt`
3. Enable GCP APIs: `gcloud services enable run.googleapis.com firestore.googleapis.com aiplatform.googleapis.com cloudscheduler.googleapis.com secretmanager.googleapis.com`
4. Deploy: `gcloud builds submit --config cloudbuild.yaml`
5. Create Cloud Scheduler job pointing at the deployed `/scheduler/run` endpoint (daily).
6. Configure Stripe product (33-day recurring, $1.99) and point its webhook at `/webhook/stripe`.

## Evidence collection (submission requirement)

Every agent run (signal generation, chat interaction, report sent) is logged to
Firestore's `evidence_log` collection with a timestamp, agent name, and outcome —
this is the source for the product evidence required in the Devpost submission.
See `docs/submission_evidence_checklist.md`.

## Not in scope (deliberately)

No pooled client capital, no trade/bet execution on a user's behalf. See
`docs/submission_evidence_checklist.md` for the disclaimer language to ship with
the product.
