"""Subscriber-facing chat agent. Handles onboarding/FAQ/signal delivery.
Deliberately never executes a bet, trade, or payment action on the user's
behalf — it only informs."""
from __future__ import annotations

import os

import google.generativeai as genai

from app.integrations.firestore_client import get_subscriber, log_evidence

genai.configure(api_key=os.environ["GEMINI_API_KEY"])
_model = genai.GenerativeModel("gemini-2.0-flash")

_SYSTEM_PROMPT = (
    "You are the customer support and onboarding assistant for a sports "
    "signals subscription. Answer questions about the subscription, explain "
    "signals in plain language, and help with onboarding. You must never: "
    "place a bet, execute a trade, take custody of funds, or instruct the "
    "user to do so through this chat. If asked to do any of those, explain "
    "that the service provides information only and the user acts on their "
    "own via their own accounts."
)


def handle_message(user_id: str, message: str) -> str:
    subscriber = get_subscriber(user_id)
    context = f"Subscriber status: {subscriber}" if subscriber else "New user."

    prompt = f"{_SYSTEM_PROMPT}\n\n{context}\n\nUser message: {message}"
    response = _model.generate_content(prompt)
    reply = response.text

    log_evidence(
        agent_name="chat_agent",
        action="handle_message",
        detail={"user_id": user_id},
    )
    return reply
