"""Turns raw signal output into a readable subscriber report using Gemini."""
from __future__ import annotations

import os
from typing import Any

import google.generativeai as genai

from app.integrations.firestore_client import log_evidence

genai.configure(api_key=os.environ["GEMINI_API_KEY"])
_model = genai.GenerativeModel("gemini-2.0-flash")

_SYSTEM_PROMPT = (
    "You are a sports signals reporting assistant. Summarise the given "
    "prediction data into a clear, factual report for a paying subscriber. "
    "Always include: (1) the signal and confidence level, (2) that this is "
    "informational only, not financial or betting advice, and the subscriber "
    "is solely responsible for any decisions they make. Never tell the user "
    "to place a bet or wager; describe the signal, not an instruction."
)


def generate_report(signals: list[dict[str, Any]]) -> str:
    prompt = f"{_SYSTEM_PROMPT}\n\nSignals:\n{signals}"
    response = _model.generate_content(prompt)
    report_text = response.text

    log_evidence(
        agent_name="report_agent",
        action="generate_report",
        detail={"signal_count": len(signals)},
    )
    return report_text
