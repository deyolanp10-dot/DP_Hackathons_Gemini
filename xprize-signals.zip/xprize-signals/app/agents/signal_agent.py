"""Wraps the existing DP01 Prophet model. Plug in the real model call here —
this module intentionally has no model logic of its own, it's the integration
seam between the hackathon service and your existing Prophet pipeline."""
from __future__ import annotations

from typing import Any

from app.integrations.firestore_client import log_evidence, save_signal


def generate_daily_signals() -> list[dict[str, Any]]:
    """Call the existing Prophet forecast pipeline and persist results.

    Replace `_call_prophet_model()` with the real DP01 model invocation
    (local inference call, subprocess, or imported module).
    """
    raw_predictions = _call_prophet_model()

    signals = []
    for pred in raw_predictions:
        signal_id = save_signal(pred)
        signals.append({**pred, "id": signal_id})

    log_evidence(
        agent_name="signal_agent",
        action="generate_daily_signals",
        detail={"count": len(signals)},
    )
    return signals


def _call_prophet_model() -> list[dict[str, Any]]:
    """Placeholder — replace with the real DP01 Prophet inference call."""
    raise NotImplementedError("Wire this to the DP01 Prophet model pipeline.")
