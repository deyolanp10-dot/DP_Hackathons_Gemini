"""Stripe webhook: provisions/revokes access on subscription events."""
from __future__ import annotations

import os

import stripe

from app.integrations.firestore_client import log_evidence, upsert_subscriber

stripe.api_key = os.environ["STRIPE_SECRET_KEY"]
_WEBHOOK_SECRET = os.environ["STRIPE_WEBHOOK_SECRET"]


def handle_webhook(payload: bytes, sig_header: str) -> dict:
    event = stripe.Webhook.construct_event(payload, sig_header, _WEBHOOK_SECRET)
    event_type = event["type"]
    obj = event["data"]["object"]

    if event_type == "checkout.session.completed":
        user_id = obj["client_reference_id"]
        upsert_subscriber(
            user_id,
            {
                "status": "active",
                "stripe_customer_id": obj.get("customer"),
                "subscription_id": obj.get("subscription"),
            },
        )
    elif event_type in ("customer.subscription.deleted", "invoice.payment_failed"):
        user_id = obj.get("client_reference_id") or obj.get("metadata", {}).get("user_id")
        if user_id:
            upsert_subscriber(user_id, {"status": "inactive"})

    log_evidence(
        agent_name="billing_agent",
        action=event_type,
        detail={"stripe_event_id": event["id"]},
    )
    return {"received": True}
