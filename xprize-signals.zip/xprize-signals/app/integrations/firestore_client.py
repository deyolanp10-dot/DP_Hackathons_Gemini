"""Firestore access layer. Single client, no business logic here."""
from __future__ import annotations

import datetime as dt
from typing import Any

from google.cloud import firestore

_db: firestore.Client | None = None


def get_client() -> firestore.Client:
    global _db
    if _db is None:
        _db = firestore.Client()
    return _db


def log_evidence(agent_name: str, action: str, detail: dict[str, Any]) -> None:
    """Append one record to evidence_log — required for submission evidence."""
    get_client().collection("evidence_log").add(
        {
            "agent": agent_name,
            "action": action,
            "detail": detail,
            "timestamp": dt.datetime.now(dt.timezone.utc),
        }
    )


def get_subscriber(user_id: str) -> dict[str, Any] | None:
    doc = get_client().collection("subscribers").document(user_id).get()
    return doc.to_dict() if doc.exists else None


def upsert_subscriber(user_id: str, data: dict[str, Any]) -> None:
    get_client().collection("subscribers").document(user_id).set(data, merge=True)


def save_signal(signal: dict[str, Any]) -> str:
    ref = get_client().collection("signals").document()
    ref.set({**signal, "created_at": dt.datetime.now(dt.timezone.utc)})
    return ref.id
