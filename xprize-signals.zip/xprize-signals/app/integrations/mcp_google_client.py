"""Client for the Google Workspace MCP server (Sheets/Drive), used for
human-readable reporting and evidence export alongside the Firestore log.

Use Google's existing Workspace MCP server rather than a bespoke
implementation — faster to stand up and a smaller security surface within
the build window. Point GOOGLE_WORKSPACE_MCP_URL at that server.

OAuth scopes should be least-privilege: restrict to a single dedicated
tracking Sheet and a single dedicated Drive folder, not full account access.
"""
from __future__ import annotations

import os
from typing import Any

_MCP_URL = os.environ.get("GOOGLE_WORKSPACE_MCP_URL", "")


def append_to_tracking_sheet(spreadsheet_id: str, row: list[Any]) -> None:
    """Append one row (e.g. a signal or evidence record) to the tracking sheet.

    Implementation depends on the chosen MCP client library / transport
    (stdio or SSE) — wire this to the Workspace MCP server's `sheets.append`
    tool once the server is running. Left as an integration seam.
    """
    raise NotImplementedError(
        "Wire to Google Workspace MCP server's sheets.append tool "
        f"at {_MCP_URL or '<set GOOGLE_WORKSPACE_MCP_URL>'}"
    )


def upload_report_to_drive(folder_id: str, filename: str, content: bytes) -> None:
    """Upload a generated report (PDF/markdown) to a dedicated Drive folder."""
    raise NotImplementedError(
        "Wire to Google Workspace MCP server's drive.upload tool "
        f"at {_MCP_URL or '<set GOOGLE_WORKSPACE_MCP_URL>'}"
    )
