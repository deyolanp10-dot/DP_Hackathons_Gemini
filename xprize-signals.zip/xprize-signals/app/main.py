"""Cloud Run entrypoint. Exposes chat, report, scheduler trigger, and the
Stripe webhook. Keep this thin — logic lives in app/agents and app/billing."""
from __future__ import annotations

from fastapi import FastAPI, Header, Request
from pydantic import BaseModel

from app.agents.chat_agent import handle_message
from app.agents.report_agent import generate_report
from app.agents.signal_agent import generate_daily_signals
from app.billing.stripe_webhook import handle_webhook

app = FastAPI(title="DP01 Prophet Signals")


class ChatRequest(BaseModel):
    user_id: str
    message: str


@app.post("/chat")
def chat(req: ChatRequest) -> dict:
    return {"reply": handle_message(req.user_id, req.message)}


@app.post("/scheduler/run")
def run_scheduled_job() -> dict:
    """Triggered by Cloud Scheduler — generates signals and a report."""
    signals = generate_daily_signals()
    report = generate_report(signals)
    return {"signal_count": len(signals), "report_preview": report[:200]}


@app.post("/webhook/stripe")
async def stripe_webhook(request: Request, stripe_signature: str = Header(None)) -> dict:
    payload = await request.body()
    return handle_webhook(payload, stripe_signature)


@app.get("/healthz")
def healthz() -> dict:
    return {"status": "ok"}
