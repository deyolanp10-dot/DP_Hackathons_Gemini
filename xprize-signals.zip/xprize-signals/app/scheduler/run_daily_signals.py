"""Standalone entrypoint for Cloud Scheduler if invoking a job directly
instead of hitting the Cloud Run /scheduler/run HTTP endpoint."""
from __future__ import annotations

from app.agents.report_agent import generate_report
from app.agents.signal_agent import generate_daily_signals


def main() -> None:
    signals = generate_daily_signals()
    generate_report(signals)


if __name__ == "__main__":
    main()
