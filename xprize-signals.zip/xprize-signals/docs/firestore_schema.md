# Firestore Schema

## `subscribers/{user_id}`
- `status`: "active" | "inactive"
- `stripe_customer_id`: string
- `subscription_id`: string
- `plan`: "33_day_1.99" (extend for the targeted plan tier)

## `signals/{signal_id}`
- raw Prophet model output (sport, event, prediction, confidence)
- `created_at`: timestamp

## `evidence_log/{doc_id}`
- `agent`: string (signal_agent | report_agent | chat_agent | billing_agent)
- `action`: string
- `detail`: map
- `timestamp`: timestamp

This collection is the primary source for the "agent execution logs / API
usage records" evidence required in the Devpost submission — export it as a
CSV/screenshot close to submission time.
