# Submission Evidence Checklist

- [ ] Category selected: Money & Financial Access
- [ ] Public/shared GitHub repo with full source
- [ ] 3-minute demo video showing agents running live
- [ ] 500–1000 word written narrative (human vs AI tasks)
- [ ] Revenue evidence: Stripe dashboard export or bank statement
- [ ] Official P&L template filled in (from Devpost resources page)
- [ ] Expenses disclosed, including marketing/customer acquisition spend (even if $0)
- [ ] Product evidence: `evidence_log` export, screenshots of chat/report output
- [ ] At least one Gemini API call present in the deployed app (chat_agent / report_agent)

## Disclaimer language to ship on the product/landing page

> This service provides informational sports predictions only. It is not
> financial or betting advice, and [Company] does not place bets, execute
> trades, or take custody of funds on your behalf. Subscribers are solely
> responsible for any decisions and actions they take. No outcome or return
> is guaranteed.

## Do not submit

- Simulated/fake customers or revenue presented as real
- Any evidence of fund custody or bet/trade execution on a client's behalf
- Lead-generation or marketing materials that target individuals by inferred
  gambling behavior or vulnerability
